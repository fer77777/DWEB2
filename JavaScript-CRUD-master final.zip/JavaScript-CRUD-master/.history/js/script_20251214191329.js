// MODIFICACIÓN Fernando: Variable global para controlar la fila seleccionada al editar - 12/12/2025
var selectedRow = null;

// MODIFICACIÓN Fernando: Función principal que maneja el envío del formulario CRUD - 12/12/2025
function onFormSubmit(){
    if (validate()) {
        var formData = readData();

        if (selectedRow == null) {
            insert(formData);
        } else {
            update(formData);
            selectedRow = null;

            // MODIFICACIÓN Fernando: Se restaura el texto del botón luego de actualizar - 12/12/2025
            document.getElementById("btnSubmit").innerText = "Agregar";
        }

        resetForm();
    }
}

// MODIFICACIÓN Fernando: Lectura de datos del formulario y creación de objeto - 12/12/2025
function readData(){
    var formData = {};
    formData["roll"] = document.getElementById("roll").value;
    formData["name"] = document.getElementById("name").value;
    formData["gender"] = document.getElementById("gender").value;
    formData["std"] = document.getElementById("std").value.toUpperCase();
    formData["dob"] = document.getElementById("dob").value;
    return formData;
}

// MODIFICACIÓN Fernando: Inserta un nuevo registro en la tabla - 12/12/2025
function insert(data){
    var table = document.getElementById("studentlist").getElementsByTagName('tbody')[0];
    var newRow = table.insertRow(table.length);

    newRow.insertCell(0).innerHTML = data.roll;
    newRow.insertCell(1).innerHTML = data.name;
    newRow.insertCell(2).innerHTML = data.gender;
    newRow.insertCell(3).innerHTML = data.std;
    newRow.insertCell(4).innerHTML = data.dob;

    // MODIFICACIÓN Fernando: Traducción de acciones Edit/Delete a español - 12/12/2025
    newRow.insertCell(5).innerHTML =
        `<a class="table-action" onClick="onEdit(this)">Editar</a>
         <a class="table-action" onClick="onDelete(this)">Eliminar</a>`;
}

// MODIFICACIÓN Fernando: Limpia el formulario después de agregar/actualizar - 12/12/2025
function resetForm(){
    document.getElementById("roll").value = "";
    document.getElementById("name").value = "";
    document.getElementById("std").value = "";
    document.getElementById("dob").value = "";
    document.getElementById("gender").selectedIndex = 0;
}

// MODIFICACIÓN Fernando: Carga los datos de la fila seleccionada en el formulario - 12/12/2025
function onEdit(td){
    selectedRow = td.parentElement.parentElement;

    document.getElementById("roll").value = selectedRow.cells[0].innerHTML;
    document.getElementById("name").value = selectedRow.cells[1].innerHTML;
    document.getElementById("gender").value = selectedRow.cells[2].innerHTML;
    document.getElementById("std").value = selectedRow.cells[3].innerHTML;
    document.getElementById("dob").value = selectedRow.cells[4].innerHTML;

    // MODIFICACIÓN Fernando: Cambio de texto del botón al modo edición - 12/12/2025
    document.getElementById("btnSubmit").innerText = "Actualizar";
}

// MODIFICACIÓN Fernando: Elimina un registro con confirmación en español - 12/12/2025
function onDelete(td){
    if (confirm("¿Desea eliminar este registro?")) {
        var row = td.parentElement.parentElement;
        document.getElementById("studentlist").deleteRow(row.rowIndex);
        resetForm();

        // MODIFICACIÓN Fernando: Se restaura el botón a 'Agregar' tras eliminar - 12/12/2025
        document.getElementById("btnSubmit").innerText = "Agregar";
    }
}

// MODIFICACIÓN Fernando: Actualiza los datos de una fila existente - 12/12/2025
function update(formData){
    selectedRow.cells[0].innerHTML = formData.roll;
    selectedRow.cells[1].innerHTML = formData.name;
    selectedRow.cells[2].innerHTML = formData.gender;
    selectedRow.cells[3].innerHTML = formData.std;
    selectedRow.cells[4].innerHTML = formData.dob;
}

// MODIFICACIÓN Fernando: Validaciones del formulario (campos obligatorios y formato) - 12/12/2025
function validate(){
    var isValid = true;

    var roll = document.getElementById("roll").value;
    var name = document.getElementById("name").value;
    var std  = document.getElementById("std").value;

    var patternRoll = /^[0-9]{6}$/;
    var patternName = /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/;
    var patternStd  = /^(?=[MDCLXVI])M*(C[MD]|D?C{0,3})(X[CL]|L?X{0,3})(I[XV]|V?I{0,3})$/;

    // MODIFICACIÓN Fernando: Validación del número de registro - 12/12/2025
    if (!patternRoll.test(roll)) {
        document.getElementById("RollValidationError").classList.remove("hide");
        isValid = false;
    } else {
        document.getElementById("RollValidationError").classList.add("hide");
    }

    // MODIFICACIÓN Fernando: Validación del nombre (solo letras) - 12/12/2025
    if (!patternName.test(name)) {
        document.getElementById("NameValidationError").classList.remove("hide");
        isValid = false;
    } else {
        document.getElementById("NameValidationError").classList.add("hide");
    }

    // MODIFICACIÓN Fernando: Validación del curso/grado en números romanos - 12/12/2025
    if (!patternStd.test(std.toUpperCase())) {
        document.getElementById("StandardValidationError").classList.remove("hide");
        isValid = false;
    } else {
        document.getElementById("StandardValidationError").classList.add("hide");
    }

    return isValid;
}
// MODIFICACIÓN Fernando: Imprime solo la tabla visible, sin botones - 12/12/2025
function printTable() {
    var table = document.getElementById("studentlist").cloneNode(true); // clona la tabla
    // Elimina la columna de operaciones para impresión
    for (var i = 0, row; row = table.rows[i]; i++) {
        if (i === 0) {
            row.deleteCell(-1); // eliminar encabezado "Operaciones"
        } else {
            row.deleteCell(-1); // eliminar botones en cada fila
        }
    }

    var newWindow = window.open('', '', 'height=600,width=800');
    newWindow.document.write('<html><head><title>Imprimir Tabla</title>');
    newWindow.document.write('<style>table{border-collapse: collapse;} table, th, td{border:1px solid black; padding:5px;}</style>');
    newWindow.document.write('</head><body>');
    newWindow.document.write(table.outerHTML);
    newWindow.document.write('</body></html>');
    newWindow.document.close();
    newWindow.print();
}
