// MODIFICACIÓN Fernando: Variable global para controlar la fila seleccionada al editar - 12/12/2025
var selectedRow = null;

// MODIFICACIÓN Fernando: Array global para almacenar los registros (y sincronizar con LocalStorage) - 12/12/2025
var studentData = [];

// MODIFICACIÓN Fernando: Inicialización al cargar la página - 12/12/2025
window.onload = function() {
    // Cargar datos de LocalStorage si existen
    if (localStorage.getItem("students")) {
        studentData = JSON.parse(localStorage.getItem("students"));
        studentData.forEach(data => insert(data, false)); // false = no actualizar LocalStorage al renderizar
    }
};

// MODIFICACIÓN Fernando: Función principal que maneja el envío del formulario CRUD - 12/12/2025
function onFormSubmit() {
    if (validate()) {
        var formData = readData();

        if (selectedRow == null) {
            insert(formData, true);
        } else {
            update(formData);
            selectedRow = null;
            document.getElementById("btnSubmit").innerText = "Agregar";
        }

        resetForm();
    }
}

// MODIFICACIÓN Fernando: Lectura de datos del formulario y creación de objeto - 12/12/2025
function readData() {
    return {
        roll: document.getElementById("roll").value,
        name: document.getElementById("name").value,
        gender: document.getElementById("gender").value,
        std: document.getElementById("std").value.toUpperCase(),
        dob: document.getElementById("dob").value
    };
}

// MODIFICACIÓN Fernando: Inserta un nuevo registro en la tabla
// Si saveToStorage = true, actualiza LocalStorage
function insert(data, saveToStorage) {
    var table = document.getElementById("studentlist").getElementsByTagName('tbody')[0];
    var newRow = table.insertRow(table.length);

    newRow.insertCell(0).innerHTML = data.roll;
    newRow.insertCell(1).innerHTML = data.name;
    newRow.insertCell(2).innerHTML = data.gender;
    newRow.insertCell(3).innerHTML = data.std;
    newRow.insertCell(4).innerHTML = data.dob;

    newRow.insertCell(5).innerHTML =
        `<a class="table-action" onClick="onEdit(this)">Editar</a>
         <a class="table-action" onClick="onDelete(this)">Eliminar</a>`;

    if (saveToStorage) {
        studentData.push(data);
        localStorage.setItem("students", JSON.stringify(studentData));
    }
}

// MODIFICACIÓN Fernando: Limpia el formulario después de agregar/actualizar
function resetForm() {
    document.getElementById("roll").value = "";
    document.getElementById("name").value = "";
    document.getElementById("std").value = "";
    document.getElementById("dob").value = "";
    document.getElementById("gender").selectedIndex = 0;
}

// MODIFICACIÓN Fernando: Carga los datos de la fila seleccionada en el formulario
function onEdit(td) {
    selectedRow = td.parentElement.parentElement;

    document.getElementById("roll").value = selectedRow.cells[0].innerHTML;
    document.getElementById("name").value = selectedRow.cells[1].innerHTML;
    document.getElementById("gender").value = selectedRow.cells[2].innerHTML;
    document.getElementById("std").value = selectedRow.cells[3].innerHTML;
    document.getElementById("dob").value = selectedRow.cells[4].innerHTML;

    document.getElementById("btnSubmit").innerText = "Actualizar";
}

// MODIFICACIÓN Fernando: Elimina un registro con confirmación
function onDelete(td) {
    if (confirm("¿Desea eliminar este registro?")) {
        var row = td.parentElement.parentElement;
        var index = row.rowIndex - 1; // Ajuste para tbody

        document.getElementById("studentlist").deleteRow(row.rowIndex);
        studentData.splice(index, 1);
        localStorage.setItem("students", JSON.stringify(studentData));

        resetForm();
        document.getElementById("btnSubmit").innerText = "Agregar";
    }
}

// MODIFICACIÓN Fernando: Actualiza los datos de una fila existente
function update(formData) {
    var index = selectedRow.rowIndex - 1;

    selectedRow.cells[0].innerHTML = formData.roll;
    selectedRow.cells[1].innerHTML = formData.name;
    selectedRow.cells[2].innerHTML = formData.gender;
    selectedRow.cells[3].innerHTML = formData.std;
    selectedRow.cells[4].innerHTML = formData.dob;

    studentData[index] = formData;
    localStorage.setItem("students", JSON.stringify(studentData));
}

// MODIFICACIÓN Fernando: Validaciones del formulario
function validate() {
    var isValid = true;

    var roll = document.getElementById("roll").value;
    var name = document.getElementById("name").value;
    var std  = document.getElementById("std").value;

    var patternRoll = /^[0-9]{6}$/;
    var patternName = /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/;
    var patternStd  = /^(?=[MDCLXVI])M*(C[MD]|D?C{0,3})(X[CL]|L?X{0,3})(I[XV]|V?I{0,3})$/;

    if (!patternRoll.test(roll)) {
        document.getElementById("RollValidationError").classList.remove("hide");
        isValid = false;
    } else {
        document.getElementById("RollValidationError").classList.add("hide");
    }

    if (!patternName.test(name)) {
        document.getElementById("NameValidationError").classList.remove("hide");
        isValid = false;
    } else {
        document.getElementById("NameValidationError").classList.add("hide");
    }

    if (!patternStd.test(std.toUpperCase())) {
        document.getElementById("StandardValidationError").classList.remove("hide");
        isValid = false;
    } else {
        document.getElementById("StandardValidationError").classList.add("hide");
    }

    return isValid;
}

// MODIFICACIÓN Fernando: Imprime solo la tabla visible, sin botones
function printTable() {
    var table = document.getElementById("studentlist").cloneNode(true);

    for (var i = 0, row; row = table.rows[i]; i++) {
        row.deleteCell(-1); // elimina columna de operaciones
    }

    var newWindow = window.open('', '', 'height=600,width=800');
    newWindow.document.write('<html><head><title>Imprimir Tabla</title>');
    newWindow.document.write('<style>table{border-collapse: collapse;} table, th, td{border:1px solid black; padding:5px;}</style>');
    newWindow.document.write('</head><body>');
    newWindow.document.write(table.outerHTML);
    newWindow.document.write('</body></html>');
    newWindow.document.close();
    newWindow.print();
}

// MODIFICACIÓN Fernando: Exportar tabla a CSV
function exportTableToCSV(filename) {
    var csv = [];
    var rows = document.querySelectorAll("#studentlist tr");

    for (var i = 0; i < rows.length; i++) {
        var row = [], cols = rows[i].querySelectorAll("td, th");
        for (var j = 0; j < cols.length - 1; j++) {
            row.push('"' + cols[j].innerText + '"');
        }
        csv.push(row.join(","));
    }

    var csvFile = new Blob([csv.join("\n")], { type: "text/csv" });
    var downloadLink = document.createElement("a");
    downloadLink.download = filename;
    downloadLink.href = window.URL.createObjectURL(csvFile);
    downloadLink.style.display = "none";
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
}
